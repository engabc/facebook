![Facebook-Scripts-DOM-Manipulation](https://i.ibb.co/hHhXkhk/B-n-sao-c-a-Facebook-Scripts-DOM-Manipulation.png)
# Facebook-Scripts-DOM-Manipulation

This repository contains many scripts with no Access Token needed for Facebook users by directly manipulating the DOM.

## Installation

No installation needed.

## Usage

Follow the guidance at the beginning of every script.

Almost all scripts do not need any manual changes, just directly run the code at the [DevTools Console](https://developers.google.com/web/tools/chrome-devtools/open).

> **NOTE: Please copy all the code to make sure that you will not get any errors.**

## Authors

- [JayremntB](https://github.com/JayremntB)

See also the list of [contributors](https://github.com/JayremntB/facebook-scripts-DOM-manipulation/contributors) who participated in this project.

## Want to contribute?

Pull requests are always welcome.

This project needs to be expanded to improve its efficiency and increase the number of scripts can be used for many purposes.

Really happy to accept and review pull requests for new functionality.

## Checkpoint Issues

While using these scripts, sometimes your Facebook account may get Checkpoint due to rapid actions.

I will not take responsibility for that situation, use it at your own risks.